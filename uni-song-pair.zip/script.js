
function generateCode() {
  const number = document.getElementById('numberInput').value;
  if (!number) {
    alert("Please enter a number");
    return;
  }
  const encoded = btoa(number + "-" + Math.floor(Math.random() * 10000));
  document.getElementById('codeOutput').value = encoded;
}

function copyCode() {
  const code = document.getElementById('codeOutput');
  code.select();
  code.setSelectionRange(0, 99999);
  navigator.clipboard.writeText(code.value);
  document.getElementById('copyStatus').innerText = "Code copied!";
}
